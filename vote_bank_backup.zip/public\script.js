// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyAR8ghUYNf6X3qFByRoc3oB9awTViBGHfM",
    authDomain: "vote-bank0414.firebaseapp.com",
    projectId: "vote-bank0414",
    storageBucket: "vote-bank0414.firebasestorage.app",
    messagingSenderId: "807287894593",
    appId: "1:807287894593:web:3ee2544444617cf5338cc0",
    measurementId: "G-WC7GM5GSS1"
};

// Service Worker 등록
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/service-worker.js')
            .then(registration => {
                console.log('ServiceWorker registration successful');
            })
            .catch(err => {
                console.log('ServiceWorker registration failed: ', err);
            });
    });
}

// Initialize Firebase
const app = firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();

let currentVoteId = null;
let isAdmin = false;
let selectedOption = null;
let selectedGender = null;

// 기존 데이터 마이그레이션 함수
async function migrateOldVotes() {
    try {
        const snapshot = await db.collection('votes').get();
        let migrationNeeded = false;
        
        for (const doc of snapshot.docs) {
            const voteData = doc.data();
            const statsRef = db.collection('voteStats').doc(doc.id);
            const statsDoc = await statsRef.get();
            
            if (!statsDoc.exists || !statsDoc.data().detailedStats) {
                migrationNeeded = true;
                
                // 기존 통계 데이터 가져오기
                const oldStatsData = statsDoc.exists ? statsDoc.data() : {
                    genderStats: {
                        male: { A: 0, B: 0 },
                        female: { A: 0, B: 0 }
                    },
                    ageStats: {
                        '10대': { A: 0, B: 0 },
                        '20대': { A: 0, B: 0 },
                        '30대': { A: 0, B: 0 },
                        '40대': { A: 0, B: 0 },
                        '50대': { A: 0, B: 0 },
                        '60대이상': { A: 0, B: 0 }
                    }
                };

                // 상세 통계 데이터 생성
                const detailedStats = {
                    male: {},
                    female: {}
                };

                // 각 성별에 대해
                ['male', 'female'].forEach(gender => {
                    // 각 연령대에 대해
                    ['10대', '20대', '30대', '40대', '50대', '60대이상'].forEach(age => {
                        detailedStats[gender][age] = { A: 0, B: 0 };
                    });
                });

                // 새로운 통계 데이터 저장
                await statsRef.set({
                    ...oldStatsData,
                    detailedStats
                });
                
                console.log(`Migrated vote statistics: ${doc.id}`);
            }
        }
        
        if (migrationNeeded) {
            console.log('Migration completed');
            await loadVoteList();
        }
    } catch (error) {
        console.error('Error during migration:', error);
    }
}

// 페이지 로드 시 초기화
document.addEventListener('DOMContentLoaded', async () => {
    console.log('페이지 로드됨');
    
    // 도메인으로 관리자/사용자 페이지 구분
    const hostname = window.location.hostname;
    isAdmin = hostname.includes('admin');
    
    // 기존 데이터 마이그레이션
    await migrateOldVotes();
    
    if (isAdmin) {
        document.getElementById('admin-section').classList.remove('hidden');
        document.getElementById('user-section').classList.add('hidden');
        loadVoteList();
    } else {
        document.getElementById('admin-section').classList.add('hidden');
        document.getElementById('user-section').classList.remove('hidden');
        loadCurrentVote();
    }

    const ageSelect = document.getElementById('ageGroup');
    if (ageSelect) {
        ageSelect.addEventListener('change', checkSubmitButton);
    }
});

// 관리자 폼 초기화 함수
function clearAdminForm() {
    document.getElementById('question').value = '';
    document.getElementById('optionA').value = '';
    document.getElementById('optionB').value = '';
    document.getElementById('startTime').value = '';
    document.getElementById('endTime').value = '';
}

function showUserPage() {
    document.getElementById('admin-section').classList.add('hidden');
    document.getElementById('user-section').classList.remove('hidden');
    loadCurrentVote();
}

// 기간 중복 체크 함수
async function checkPeriodOverlap(startTime, endTime, currentVoteId = null) {
    try {
        const votesRef = db.collection('votes');
        const snapshot = await votesRef
            .where('status', '!=', 'ended') // 종료된 투표 제외
            .get();
        
        const newStart = new Date(startTime);
        const newEnd = new Date(endTime);
        
        for (const doc of snapshot.docs) {
            // 현재 수정 중인 투표는 제외
            if (currentVoteId && doc.id === currentVoteId) continue;
            
            const vote = doc.data();
            const existingStart = vote.startTime.toDate();
            const existingEnd = vote.endTime.toDate();
            
            // 기간 중복 체크
            if (
                (newStart >= existingStart && newStart <= existingEnd) || // 새 시작일이 기존 기간 내에 있는 경우
                (newEnd >= existingStart && newEnd <= existingEnd) || // 새 종료일이 기존 기간 내에 있는 경우
                (newStart <= existingStart && newEnd >= existingEnd) // 새 기간이 기존 기간을 포함하는 경우
            ) {
                return {
                    overlap: true,
                    existingVote: {
                        start: formatDateTime(existingStart),
                        end: formatDateTime(existingEnd),
                        status: vote.status
                    }
                };
            }
        }
        return { overlap: false };
    } catch (error) {
        console.error('Error checking period overlap:', error);
        throw error;
    }
}

// 투표 저장 함수
async function saveVote() {
    const question = document.getElementById('question').value;
    const optionA = document.getElementById('optionA').value;
    const optionB = document.getElementById('optionB').value;
    const startTime = document.getElementById('startTime').value;
    const endTime = document.getElementById('endTime').value;

    if (!question || !optionA || !optionB || !startTime || !endTime) {
        alert('모든 필드를 입력해주세요');
        return;
    }

    const start = new Date(startTime);
    const end = new Date(endTime);

    if (end <= start) {
        alert('마감일시는 시작일시보다 늦어야 합니다');
        return;
    }

    try {
        // 기간 중복 체크
        const overlapCheck = await checkPeriodOverlap(startTime, endTime);
        if (overlapCheck.overlap) {
            alert(`다음 기간과 중복됩니다:\n${overlapCheck.existingVote.start} ~ ${overlapCheck.existingVote.end}`);
            return;
        }

        await db.collection('votes').add({
            question,
            optionA,
            optionB,
            startTime: firebase.firestore.Timestamp.fromDate(start),
            endTime: firebase.firestore.Timestamp.fromDate(end),
            votesA: 0,
            votesB: 0,
            status: 'waiting',
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });

        // 폼 초기화
        clearAdminForm();
        alert('투표가 저장되었습니다.');
        
        // 투표 목록 새로고침
        loadVoteList();
    } catch (error) {
        console.error('Error saving vote:', error);
        alert('투표 저장 중 오류가 발생했습니다');
    }
}

// 투표 목록 로드 함수
async function loadVoteList() {
    const voteListBody = document.getElementById('voteListBody');
    voteListBody.innerHTML = '';

    try {
        const snapshot = await db.collection('votes')
            .orderBy('startTime', 'desc')
            .get();
        
        const now = new Date();
        
        snapshot.forEach(doc => {
            const vote = doc.data();
            const row = document.createElement('tr');
            
            const startTime = vote.startTime.toDate();
            const endTime = vote.status === 'ended' && vote.endedAt ? vote.endedAt.toDate() : vote.endTime.toDate();
            
            // 상태 확인
            let status;
            let actionButtons = '';
            
            if (vote.status === 'ended') {
                status = '종료됨';
                actionButtons = `<button onclick="deleteVote('${doc.id}')" class="delete-btn">삭제</button>`;
            } else if (now < startTime) {
                status = '대기중';
                actionButtons = `
                    <button onclick="editVote('${doc.id}')" class="edit-btn">수정</button>
                    <button onclick="deleteVote('${doc.id}')" class="delete-btn">삭제</button>
                `;
            } else if (now > endTime) {
                status = '종료됨';
                actionButtons = `<button onclick="deleteVote('${doc.id}')" class="delete-btn">삭제</button>`;
                // 자동으로 상태 업데이트
                db.collection('votes').doc(doc.id).update({ 
                    status: 'ended',
                    endedAt: firebase.firestore.Timestamp.fromDate(endTime)
                });
            } else {
                status = '진행중';
                actionButtons = `
                    <button onclick="endVote('${doc.id}')" class="end-vote-btn">종료</button>
                    <button onclick="deleteVote('${doc.id}')" class="delete-btn">삭제</button>
                `;
            }

            const leftVotes = vote.votesA || 0;
            const rightVotes = vote.votesB || 0;
            const leftPercentage = calculatePercentage(leftVotes, rightVotes);
            const rightPercentage = calculatePercentage(rightVotes, leftVotes);
            
            // 결과 셀 스타일링을 위한 클래스 추가
            const leftResultClass = leftPercentage > rightPercentage ? 'winning-result' : '';
            const rightResultClass = rightPercentage > leftPercentage ? 'winning-result' : '';
            
            row.innerHTML = `
                <td>${formatDateTime(startTime)} ~ ${formatDateTime(endTime)}</td>
                <td>${vote.optionA}</td>
                <td>${vote.optionB}</td>
                <td class="${leftResultClass}">${leftVotes} (${leftPercentage}%)</td>
                <td class="${rightResultClass}">${rightVotes} (${rightPercentage}%)</td>
                <td>
                    ${status}
                    <div class="action-buttons">
                        ${actionButtons}
                    </div>
                </td>
            `;
            
            // 종료된 투표만 클릭 가능하도록 설정
            if (status === '종료됨') {
                row.style.cursor = 'pointer';
                row.onclick = (e) => {
                    // 버튼 클릭 시 상세 정보 표시 방지
                    if (!e.target.closest('button')) {
                        showVoteDetails(doc.id);
                    }
                };
            }
            
            voteListBody.appendChild(row);
        });
    } catch (error) {
        console.error('Error loading vote list:', error);
    }
}

// 날짜 시간 포맷팅 함수
function formatDateTime(date) {
    return date.toLocaleString('ko-KR', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        hour12: false
    }).replace(/\./g, '. ').replace(',', '');
}

// 현재 투표 로드 함수
async function loadCurrentVote() {
    try {
        // 선택 상태 초기화
        selectedOption = null;
        selectedGender = null;
        
        // UI 초기화
        document.querySelectorAll('.vote-circle').forEach(btn => {
            btn.classList.remove('selected');
            btn.disabled = false;
        });
        document.querySelectorAll('.gender-btn').forEach(btn => {
            btn.classList.remove('selected');
            btn.disabled = false;
        });
        const ageSelect = document.getElementById('ageGroup');
        if (ageSelect) {
            ageSelect.value = '';
            ageSelect.disabled = false;
        }
        
        document.querySelector('.submit-btn').disabled = true;
        document.querySelector('.result-graph').classList.add('hidden');
        document.querySelector('.result-graph').classList.remove('show');
        document.querySelector('.vote-options').style.display = 'flex';
        document.querySelector('.user-info-form').style.display = 'block';

        // 이전에 추가된 다음 투표 정보가 있다면 모두 제거
        document.querySelectorAll('.next-vote-info').forEach(el => el.remove());

        const now = new Date();
        // 단순히 모든 투표를 가져오고 클라이언트에서 필터링
        const snapshot = await db.collection('votes').get();

        let currentVoteDoc = null;
        let nextVoteDoc = null;
        
        // 클라이언트 측에서 현재 시간에 해당하는 투표 찾기
        const sortedDocs = snapshot.docs
            .map(doc => ({ id: doc.id, data: doc.data() }))
            .filter(doc => doc.data.status !== 'ended')  // 종료되지 않은 투표만 필터링
            .sort((a, b) => {
                // startTime이 없는 경우 처리
                if (!a.data.startTime || !b.data.startTime) return 0;
                return a.data.startTime.toDate() - b.data.startTime.toDate();
            });

        // 현재 진행 중이거나 다음 예정된 투표 찾기
        for (const doc of sortedDocs) {
            const data = doc.data;
            
            // startTime과 endTime이 있는지 확인
            if (!data.startTime || !data.endTime) {
                console.warn('Vote document missing time fields:', doc.id);
                continue;
            }

            const startTime = data.startTime.toDate();
            const endTime = data.endTime.toDate();
            
            // 현재 시간이 시작시간과 종료시간 사이에 있는 경우
            if (now >= startTime && now <= endTime) {
                currentVoteDoc = { id: doc.id, data: data };
                break;
            }
            
            // 다음 예정된 투표 찾기 (현재 시간보다 나중에 시작하는 첫 번째 투표)
            if (now < startTime && !nextVoteDoc) {
                nextVoteDoc = { id: doc.id, data: data };
            }
        }

        if (!currentVoteDoc) {
            document.getElementById('currentQuestion').textContent = '현재 진행중인 투표가 없습니다.';
            document.getElementById('optionAButton').textContent = 'A';
            document.getElementById('optionBButton').textContent = 'B';
            
            // 투표 버튼 비활성화
            document.querySelectorAll('.vote-circle').forEach(btn => {
                btn.disabled = true;
                btn.style.opacity = '0.5';
            });
            document.querySelector('.user-info-form').style.display = 'none';
            document.querySelector('.result-graph').style.display = 'none';
            
            // 다음 투표 정보 표시 (기존 정보가 있다면 제거 후 새로 추가)
            document.querySelectorAll('.next-vote-info').forEach(el => el.remove());
            
            const nextVoteInfo = document.createElement('div');
            nextVoteInfo.className = 'next-vote-info';
            if (nextVoteDoc) {
                const nextStartTime = nextVoteDoc.data.startTime.toDate();
                nextVoteInfo.textContent = `다음 투표 개시: ${formatDateTime(nextStartTime)}`;
            } else {
                nextVoteInfo.textContent = '예정된 다음 투표가 없습니다.';
            }
            
            // 이전 투표 보기 버튼 앞에 다음 투표 정보 삽입
            const previousVotesBtn = document.querySelector('.previous-votes-btn');
            if (previousVotesBtn) {
                previousVotesBtn.parentNode.insertBefore(nextVoteInfo, previousVotesBtn);
            }
            
            currentVoteId = null;
            return;
        }

        const voteData = currentVoteDoc.data;
        currentVoteId = currentVoteDoc.id;

        // 질문과 투표 옵션 업데이트
        document.getElementById('currentQuestion').textContent = voteData.question;
        document.getElementById('optionAButton').textContent = voteData.optionA;
        document.getElementById('optionBButton').textContent = voteData.optionB;

        // 투표 옵션과 그래프 표시
        document.querySelector('.vote-options').style.display = 'flex';
        document.querySelector('.result-graph').style.display = 'block';

        // 초기 결과 업데이트
        updateResults(voteData.votesA || 0, voteData.votesB || 0);

        // 실시간 업데이트 리스너 설정
        if (currentVoteId) {
            const unsubscribe = db.collection('votes').doc(currentVoteId)
                .onSnapshot((doc) => {
                    if (doc.exists) {
                        const data = doc.data();
                        updateResults(data.votesA || 0, data.votesB || 0);
                    }
                });
            
            // 이전 리스너 제거
            return () => unsubscribe();
        }

    } catch (error) {
        console.error('Error loading current vote:', error);
        document.getElementById('currentQuestion').textContent = '투표를 불러오는 중 오류가 발생했습니다.';
        document.querySelector('.vote-options').style.display = 'none';
        document.querySelector('.user-info-form').style.display = 'none';
        document.querySelector('.result-graph').style.display = 'none';
    }
}

// 투표 옵션 선택
function selectOption(option) {
    selectedOption = option;
    document.querySelectorAll('.vote-circle').forEach(btn => {
        btn.classList.remove('selected');
    });
    document.getElementById(`option${option}Button`).classList.add('selected');
    checkSubmitButton();
}

// 성별 선택
function selectGender(gender) {
    selectedGender = gender;
    document.querySelectorAll('.gender-btn').forEach(btn => {
        btn.classList.remove('selected');
    });
    if (gender === '남자') {
        document.getElementById('maleBtn').classList.add('selected');
    } else {
        document.getElementById('femaleBtn').classList.add('selected');
    }
    checkSubmitButton();
}

// 제출 버튼 활성화 체크
function checkSubmitButton() {
    const submitBtn = document.querySelector('.submit-btn');
    const ageGroup = document.getElementById('ageGroup').value;
    submitBtn.disabled = !selectedOption || !selectedGender || !ageGroup;
}

// 투표 제출
async function submitVote() {
    if (!currentVoteId || !selectedOption || !selectedGender) {
        alert('모든 항목을 선택해주세요.');
        return;
    }

    const ageGroup = document.getElementById('ageGroup').value;
    if (!ageGroup) {
        alert('연령대를 선택해주세요.');
        return;
    }

    try {
        const voteRef = db.collection('votes').doc(currentVoteId);
        const statsRef = db.collection('voteStats').doc(currentVoteId);
        
        // Firestore 트랜잭션 사용
        await db.runTransaction(async (transaction) => {
            const voteDoc = await transaction.get(voteRef);
            const statsDoc = await transaction.get(statsRef);
            
            if (!voteDoc.exists) {
                throw new Error('Vote not found');
            }

            // 통계 데이터 가져오기 또는 초기화
            let statsData = statsDoc.exists ? statsDoc.data() : {};
            
            // 성별 통계 초기화
            if (!statsData.genderStats) {
                statsData.genderStats = {
                    male: { A: 0, B: 0 },
                    female: { A: 0, B: 0 }
                };
            }
            
            // 연령대 통계 초기화
            if (!statsData.ageStats) {
                statsData.ageStats = {
                    '10대': { A: 0, B: 0 },
                    '20대': { A: 0, B: 0 },
                    '30대': { A: 0, B: 0 },
                    '40대': { A: 0, B: 0 },
                    '50대': { A: 0, B: 0 },
                    '60대이상': { A: 0, B: 0 }
                };
            }
            
            // 상세 통계 초기화
            if (!statsData.detailedStats) {
                statsData.detailedStats = {
                    male: {},
                    female: {}
                };
            }

            const genderKey = selectedGender === '남자' ? 'male' : 'female';
            
            // 성별별 통계 업데이트
            if (!statsData.genderStats[genderKey]) {
                statsData.genderStats[genderKey] = { A: 0, B: 0 };
            }
            statsData.genderStats[genderKey][selectedOption] += 1;
            
            // 연령대별 통계 업데이트
            if (!statsData.ageStats[ageGroup]) {
                statsData.ageStats[ageGroup] = { A: 0, B: 0 };
            }
            statsData.ageStats[ageGroup][selectedOption] += 1;
            
            // 상세 통계 업데이트
            if (!statsData.detailedStats[genderKey][ageGroup]) {
                statsData.detailedStats[genderKey][ageGroup] = { A: 0, B: 0 };
            }
            statsData.detailedStats[genderKey][ageGroup][selectedOption] += 1;

            // 총 투표수 업데이트
            const updateData = {};
            if (selectedOption === 'A') {
                updateData.votesA = firebase.firestore.FieldValue.increment(1);
            } else {
                updateData.votesB = firebase.firestore.FieldValue.increment(1);
            }

            // 트랜잭션으로 데이터 업데이트
            transaction.update(voteRef, updateData);
            transaction.set(statsRef, statsData);
        });

        // UI 업데이트
        document.querySelector('.result-graph').classList.remove('hidden');
        setTimeout(() => {
            document.querySelector('.result-graph').classList.add('show');
        }, 100);

        // 투표 옵션 비활성화
        document.querySelectorAll('.vote-circle').forEach(btn => {
            btn.disabled = true;
        });
        document.querySelectorAll('.gender-btn').forEach(btn => {
            btn.disabled = true;
        });
        document.getElementById('ageGroup').disabled = true;
        document.querySelector('.submit-btn').disabled = true;

    } catch (error) {
        console.error('Error submitting vote:', error);
        alert('투표 중 오류가 발생했습니다.');
    }
}

// 투표 함수
async function vote(option) {
    try {
        if (!currentVoteId) {
            alert('현재 진행 중인 투표가 없습니다.');
            return;
        }

        const voteRef = db.collection('votes').doc(currentVoteId);
        const voteDoc = await voteRef.get();
        
        if (!voteDoc.exists) {
            console.error('Vote not found');
            return;
        }

        // 투표 데이터 업데이트
        const updateData = {};
        if (option === 'A') {
            updateData.votesA = firebase.firestore.FieldValue.increment(1);
        } else {
            updateData.votesB = firebase.firestore.FieldValue.increment(1);
        }

        await voteRef.update(updateData);

        // 투표 후 결과 즉시 업데이트
        const updatedDoc = await voteRef.get();
        const updatedData = updatedDoc.data();
        updateResults(updatedData.votesA || 0, updatedData.votesB || 0);
        
    } catch (error) {
        console.error('Error voting:', error);
        alert('투표 중 오류가 발생했습니다.');
    }
}

// 투표 종료 함수
async function endVote(voteId) {
    try {
        const now = new Date();
        await db.collection('votes').doc(voteId).update({
            status: 'ended',
            endTime: firebase.firestore.Timestamp.fromDate(now),
            endedAt: firebase.firestore.Timestamp.fromDate(now)
        });
        loadVoteList();
    } catch (error) {
        console.error('Error ending vote:', error);
        alert('투표 종료 중 오류가 발생했습니다');
    }
}

// 결과 업데이트 함수
function updateResults(votesA, votesB) {
    const total = votesA + votesB;
    const percentageA = total === 0 ? 50 : (votesA / total) * 100;
    const percentageB = total === 0 ? 50 : (votesB / total) * 100;

    const barA = document.getElementById('barA');
    const barB = document.getElementById('barB');

    barA.style.width = `${percentageA}%`;
    barB.style.width = `${percentageB}%`;

    barA.textContent = `${Math.round(percentageA)}%`;
    barB.textContent = `${Math.round(percentageB)}%`;

    document.getElementById('countA').textContent = `${votesA}표`;
    document.getElementById('countB').textContent = `${votesB}표`;
}

// 퍼센트 계산 함수
function calculatePercentage(votes, otherVotes) {
    const total = votes + otherVotes;
    return total === 0 ? 0 : Math.round((votes / total) * 100);
}

// 이전 투표 보기 함수
async function showPreviousVotes() {
    const modal = document.getElementById('previousVotesModal');
    const tbody = document.getElementById('previousVotesBody');
    tbody.innerHTML = '';
    modal.classList.remove('hidden');

    try {
        const votesRef = db.collection('votes');
        const snapshot = await votesRef
            .orderBy('startTime', 'desc')
            .get();

        const now = new Date();
        
        snapshot.forEach(doc => {
            const vote = doc.data();
            const exposureTime = vote.startTime.toDate();
            const endTime = vote.endTime.toDate();
            
            // 종료된 투표만 표시
            if (now > endTime || vote.status === 'ended') {
                const row = document.createElement('tr');
                
                // 투표명
                const titleCell = document.createElement('td');
                titleCell.textContent = vote.question;
                
                // A 항목
                const aItemCell = document.createElement('td');
                aItemCell.textContent = vote.optionA;
                
                // B 항목
                const bItemCell = document.createElement('td');
                bItemCell.textContent = vote.optionB;
                
                // A 결과
                const aResultCell = document.createElement('td');
                const totalVotes = (vote.votesA || 0) + (vote.votesB || 0);
                const aPercentage = totalVotes > 0 ? Math.round((vote.votesA || 0) / totalVotes * 100) : 0;
                const aVotes = vote.votesA || 0;
                const aText = `${aVotes} (${aPercentage}%)`;
                aResultCell.textContent = aText;
                if (aPercentage > (vote.votesB || 0) / totalVotes * 100) {
                    aResultCell.style.color = '#2196F3';
                }
                
                // B 결과
                const bResultCell = document.createElement('td');
                const bPercentage = totalVotes > 0 ? Math.round((vote.votesB || 0) / totalVotes * 100) : 0;
                const bVotes = vote.votesB || 0;
                const bText = `${bVotes} (${bPercentage}%)`;
                bResultCell.textContent = bText;
                if (bPercentage > aPercentage) {
                    bResultCell.style.color = '#2196F3';
                }
                
                row.appendChild(titleCell);
                row.appendChild(aItemCell);
                row.appendChild(bItemCell);
                row.appendChild(aResultCell);
                row.appendChild(bResultCell);

                // 행 클릭 이벤트 추가
                row.style.cursor = 'pointer';
                row.onclick = () => {
                    showVoteDetails(doc.id);
                    closePreviousVotes(); // 이전 투표 목록 모달 닫기
                };
                
                tbody.appendChild(row);
            }
        });
    } catch (error) {
        console.error('Error loading previous votes:', error);
        alert('이전 투표 목록을 불러오는 중 오류가 발생했습니다.');
    }
}

// 이전 투표 목록 모달 닫기
function closePreviousVotes() {
    document.getElementById('previousVotesModal').classList.add('hidden');
}

// 투표 상세 정보 표시 함수
async function showVoteDetails(voteId) {
    try {
        // 투표 정보 가져오기
        const voteDoc = await db.collection('votes').doc(voteId).get();
        if (!voteDoc.exists) {
            console.error('Vote not found');
            return;
        }

        const voteData = voteDoc.data();
        
        // 통계 정보 가져오기
        const statsDoc = await db.collection('voteStats').doc(voteId).get();
        const statsData = statsDoc.exists ? statsDoc.data() : {
            genderStats: {
                male: { A: 0, B: 0 },
                female: { A: 0, B: 0 }
            },
            ageStats: {
                '10대': { A: 0, B: 0 },
                '20대': { A: 0, B: 0 },
                '30대': { A: 0, B: 0 },
                '40대': { A: 0, B: 0 },
                '50대': { A: 0, B: 0 },
                '60대이상': { A: 0, B: 0 }
            },
            detailedStats: {
                male: {
                    '10대': { A: 0, B: 0 },
                    '20대': { A: 0, B: 0 },
                    '30대': { A: 0, B: 0 },
                    '40대': { A: 0, B: 0 },
                    '50대': { A: 0, B: 0 },
                    '60대이상': { A: 0, B: 0 }
                },
                female: {
                    '10대': { A: 0, B: 0 },
                    '20대': { A: 0, B: 0 },
                    '30대': { A: 0, B: 0 },
                    '40대': { A: 0, B: 0 },
                    '50대': { A: 0, B: 0 },
                    '60대이상': { A: 0, B: 0 }
                }
            }
        };

        // 제목과 옵션 설정
        document.getElementById('voteDetailTitle').textContent = voteData.question;
        document.getElementById('optionATitle').textContent = voteData.optionA;
        document.getElementById('optionBTitle').textContent = voteData.optionB;

        // 통계 테이블 업데이트
        await updateStatsTable('A', statsData, voteId);
        await updateStatsTable('B', statsData, voteId);

        // 모달 표시
        document.getElementById('voteDetailsModal').classList.remove('hidden');
    } catch (error) {
        console.error('Error loading vote details:', error);
        alert('투표 상세 정보를 불러오는 중 오류가 발생했습니다.');
    }
}

// 통계 테이블 업데이트 함수
async function updateStatsTable(option, statsData, voteId) {
    const maleStats = document.getElementById(`option${option}MaleStats`).children;
    const femaleStats = document.getElementById(`option${option}FemaleStats`).children;
    const ageGroups = ['10대', '20대', '30대', '40대', '50대', '60대이상'];
    
    let maleTotalVotes = 0;
    let femaleTotalVotes = 0;

    // 데이터가 없는 경우 초기화
    if (!statsData.detailedStats) {
        statsData.detailedStats = {
            male: {},
            female: {}
        };
    }

    // 남성 통계
    ageGroups.forEach((age, index) => {
        if (!statsData.detailedStats.male[age]) {
            statsData.detailedStats.male[age] = { A: 0, B: 0 };
        }
        const maleCount = statsData.detailedStats.male[age][option] || 0;
        maleTotalVotes += maleCount;
        maleStats[index].textContent = maleCount;
    });
    maleStats[6].textContent = maleTotalVotes; // 소계

    // 여성 통계
    ageGroups.forEach((age, index) => {
        if (!statsData.detailedStats.female[age]) {
            statsData.detailedStats.female[age] = { A: 0, B: 0 };
        }
        const femaleCount = statsData.detailedStats.female[age][option] || 0;
        femaleTotalVotes += femaleCount;
        femaleStats[index].textContent = femaleCount;
    });
    femaleStats[6].textContent = femaleTotalVotes; // 소계

    // 총계 표시 (성별 통계의 합으로 계산)
    const totalVotes = maleTotalVotes + femaleTotalVotes;
    const optionStats = document.getElementById(`option${option}Title`).parentElement;
    optionStats.querySelector('.vote-count-total').textContent = `총 ${totalVotes}표`;
}

// 투표 상세 정보 모달 닫기
function closeVoteDetails() {
    document.getElementById('voteDetailsModal').classList.add('hidden');
    // 관리자 페이지가 아닌 경우에만 이전 투표 목록 다시 표시
    if (!isAdmin) {
        document.getElementById('previousVotesModal').classList.remove('hidden');
    }
}

// 투표 삭제 함수
async function deleteVote(voteId) {
    if (!confirm('정말 이 투표를 삭제하시겠습니까?')) {
        return;
    }

    try {
        // 투표 문서 삭제
        await db.collection('votes').doc(voteId).delete();
        // 관련 통계 데이터 삭제
        await db.collection('voteStats').doc(voteId).delete();
        
        alert('투표가 삭제되었습니다.');
        loadVoteList(); // 목록 새로고침
    } catch (error) {
        console.error('Error deleting vote:', error);
        alert('투표 삭제 중 오류가 발생했습니다.');
    }
}

// 투표 수정 함수
async function editVote(voteId) {
    try {
        const voteDoc = await db.collection('votes').doc(voteId).get();
        if (!voteDoc.exists) {
            alert('투표를 찾을 수 없습니다.');
            return;
        }

        const vote = voteDoc.data();
        
        // 폼에 기존 데이터 설정
        document.getElementById('question').value = vote.question;
        document.getElementById('optionA').value = vote.optionA;
        document.getElementById('optionB').value = vote.optionB;
        document.getElementById('startTime').value = formatDateTimeForInput(vote.startTime.toDate());
        document.getElementById('endTime').value = formatDateTimeForInput(vote.endTime.toDate());
        
        // 저장 버튼의 동작을 수정 모드로 변경
        const saveButton = document.querySelector('.vote-form button');
        saveButton.textContent = '수정';
        saveButton.onclick = () => updateVote(voteId);
    } catch (error) {
        console.error('Error loading vote for edit:', error);
        alert('투표 정보를 불러오는 중 오류가 발생했습니다.');
    }
}

// input type="datetime-local"용 날짜 포맷팅 함수
function formatDateTimeForInput(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    
    return `${year}-${month}-${day}T${hours}:${minutes}`;
}

// 투표 업데이트 함수
async function updateVote(voteId) {
    const question = document.getElementById('question').value;
    const optionA = document.getElementById('optionA').value;
    const optionB = document.getElementById('optionB').value;
    const startTime = document.getElementById('startTime').value;
    const endTime = document.getElementById('endTime').value;

    if (!question || !optionA || !optionB || !startTime || !endTime) {
        alert('모든 필드를 입력해주세요');
        return;
    }

    const start = new Date(startTime);
    const end = new Date(endTime);

    if (end <= start) {
        alert('마감일시는 시작일시보다 늦어야 합니다');
        return;
    }

    try {
        // 다른 투표와의 기간 중복 체크
        const overlapCheck = await checkPeriodOverlap(startTime, endTime, voteId);
        if (overlapCheck.overlap) {
            alert(`다음 기간과 중복됩니다:\n${overlapCheck.existingVote.start} ~ ${overlapCheck.existingVote.end}`);
            return;
        }

        await db.collection('votes').doc(voteId).update({
            question,
            optionA,
            optionB,
            startTime: firebase.firestore.Timestamp.fromDate(start),
            endTime: firebase.firestore.Timestamp.fromDate(end),
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });

        // 폼 초기화 및 버튼 상태 복구
        clearAdminForm();
        const saveButton = document.querySelector('.vote-form button');
        saveButton.textContent = '저장';
        saveButton.onclick = saveVote;

        alert('투표가 수정되었습니다.');
        loadVoteList();
    } catch (error) {
        console.error('Error updating vote:', error);
        alert('투표 수정 중 오류가 발생했습니다');
    }
}
