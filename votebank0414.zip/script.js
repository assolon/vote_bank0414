// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyC88rg8vh58Hv4wfJYQG6npRz7uz1dqSIQ",
    authDomain: "vote-bank0413-7027d.firebaseapp.com",
    projectId: "vote-bank0413-7027d",
    storageBucket: "vote-bank0413-7027d.firebasestorage.app",
    messagingSenderId: "511906103211",
    appId: "1:511906103211:web:66aacb8f2cf8490f9f9cee",
    measurementId: "G-F8F87TBB7F"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();

let currentVoteId = null;
let isAdmin = false;  // 관리자 상태를 추적하는 변수

// 전역 함수로 선언
function showAdminPage() {
    document.getElementById('admin-section').classList.remove('hidden');
    document.getElementById('user-section').classList.add('hidden');
    loadVoteList();
}

function showUserPage() {
    document.getElementById('admin-section').classList.add('hidden');
    document.getElementById('user-section').classList.remove('hidden');
    loadCurrentVote();
}

// 투표 저장 함수
async function saveVote() {
    const question = document.getElementById('question').value;
    const optionA = document.getElementById('optionA').value;
    const optionB = document.getElementById('optionB').value;
    const exposureTime = document.getElementById('exposureTime').value;

    if (!question || !optionA || !optionB || !exposureTime) {
        alert('모든 필드를 입력해주세요');
        return;
    }

    try {
        await db.collection('votes').add({
            question,
            optionA,
            optionB,
            exposureTime: new Date(exposureTime),
            votesA: 0,
            votesB: 0,
            status: 'active',
            createdAt: new Date()
        });

        // 폼 초기화
        document.getElementById('question').value = '';
        document.getElementById('optionA').value = '';
        document.getElementById('optionB').value = '';
        document.getElementById('exposureTime').value = '';

        // 투표 목록 새로고침
        loadVoteList();
    } catch (error) {
        console.error('Error saving vote:', error);
        alert('투표 저장 중 오류가 발생했습니다');
    }
}

// 투표 목록 로드 함수
async function loadVoteList() {
    const voteListBody = document.getElementById('voteListBody');
    voteListBody.innerHTML = '';

    try {
        const snapshot = await db.collection('votes').orderBy('createdAt', 'desc').get();
        const now = new Date();
        
        snapshot.forEach(doc => {
            const vote = doc.data();
            const row = document.createElement('tr');
            
            // Firestore Timestamp를 Date 객체로 변환
            const exposureTime = vote.exposureTime.toDate();
            const endTime = new Date(exposureTime.getTime() + 60 * 60 * 1000); // 1시간 후
            
            // 투표 상태 결정
            let status;
            let actionButton = '';
            
            if (vote.status === 'ended') {
                status = '종료됨';
            } else if (now < exposureTime) {
                status = '대기중';
            } else if (now > endTime) {
                status = '종료됨';
                // 자동으로 상태 업데이트
                db.collection('votes').doc(doc.id).update({ status: 'ended' });
            } else {
                status = '진행중';
                actionButton = `<button onclick="endVote('${doc.id}')">종료</button>`;
            }
            
            row.innerHTML = `
                <td>${exposureTime.toLocaleString('ko-KR', {
                    year: 'numeric',
                    month: '2-digit',
                    day: '2-digit',
                    hour: '2-digit',
                    minute: '2-digit'
                })}</td>
                <td>${vote.optionA}</td>
                <td>${vote.optionB}</td>
                <td>${vote.votesA} (${calculatePercentage(vote.votesA, vote.votesB)}%)</td>
                <td>${vote.votesB} (${calculatePercentage(vote.votesB, vote.votesA)}%)</td>
                <td>${status}${actionButton}</td>
            `;
            
            voteListBody.appendChild(row);
        });
    } catch (error) {
        console.error('Error loading vote list:', error);
    }
}

// 현재 투표 로드 함수
async function loadCurrentVote() {
    try {
        console.log('투표 로딩 시작');
        const now = new Date();
        console.log('현재 시간:', now);
        
        // 모든 투표를 가져와서 클라이언트에서 필터링
        const querySnapshot = await db.collection('votes')
            .orderBy('exposureTime', 'desc')
            .get();

        console.log('총 투표 수:', querySnapshot.size);
        
        // 현재 시간에 해당하는 투표 찾기
        let currentVote = null;
        querySnapshot.forEach(doc => {
            const vote = doc.data();
            const exposureTime = vote.exposureTime.toDate();
            const endTime = new Date(exposureTime.getTime() + 60 * 60 * 1000); // 1시간 후
            
            console.log('투표 확인:', {
                id: doc.id,
                status: vote.status,
                exposureTime: exposureTime,
                endTime: endTime,
                now: now
            });
            
            // 아직 종료되지 않은 투표 중에서 노출 시간이 지난 가장 최근 투표
            if (vote.status !== 'ended' && now >= exposureTime && now <= endTime) {
                currentVote = { id: doc.id, ...vote };
                console.log('현재 투표 찾음:', currentVote);
                return false; // forEach 루프 중단
            }
        });

        if (!currentVote) {
            console.log('진행 중인 투표 없음');
            document.getElementById('currentQuestion').textContent = '현재 진행 중인 투표가 없습니다';
            document.getElementById('option1').textContent = '';
            document.getElementById('option2').textContent = '';
            document.getElementById('result-container').classList.add('hidden');
            return;
        }

        console.log('투표 표시 시작');
        currentVoteId = currentVote.id;
        
        document.getElementById('currentQuestion').textContent = currentVote.question;
        document.getElementById('option1').textContent = currentVote.optionA;
        document.getElementById('option2').textContent = currentVote.optionB;

        // 투표 결과 표시
        updateResults(currentVote.votesA, currentVote.votesB);
        document.getElementById('result-container').classList.remove('hidden');

    } catch (error) {
        console.error('Error loading current vote:', error);
        document.getElementById('currentQuestion').textContent = '투표 로딩 중 오류가 발생했습니다';
    }
}

// 투표 함수
async function vote(option) {
    try {
        const voteId = currentVoteId;
        if (!voteId) {
            alert('현재 진행 중인 투표가 없습니다.');
            return;
        }

        const voteRef = db.collection('votes').doc(voteId);
        const voteDoc = await voteRef.get();
        
        if (!voteDoc.exists) {
            console.error('Vote not found');
            return;
        }

        // 투표 데이터 업데이트
        if (option === 'A') {
            await voteRef.update({
                votesA: firebase.firestore.FieldValue.increment(1)
            });
        } else {
            await voteRef.update({
                votesB: firebase.firestore.FieldValue.increment(1)
            });
        }

        console.log('투표 완료:', {
            voteId,
            option
        });

        // 투표 후 결과 즉시 업데이트
        const updatedDoc = await voteRef.get();
        const updatedData = updatedDoc.data();
        updateResults(updatedData.votesA || 0, updatedData.votesB || 0);
        
    } catch (error) {
        console.error('Error voting:', error);
        alert('투표 중 오류가 발생했습니다.');
    }
}

// 투표 종료 함수
async function endVote(voteId) {
    try {
        await db.collection('votes').doc(voteId).update({
            status: 'ended',
            endedAt: new Date()
        });
        loadVoteList();
    } catch (error) {
        console.error('Error ending vote:', error);
        alert('투표 종료 중 오류가 발생했습니다');
    }
}

// 결과 업데이트 함수
function updateResults(votesA, votesB) {
    console.log('결과 업데이트:', { votesA, votesB });
    const total = votesA + votesB;
    const percentageA = calculatePercentage(votesA, votesB);
    const percentageB = calculatePercentage(votesB, votesA);

    const barA = document.getElementById('barA');
    const barB = document.getElementById('barB');
    
    if (barA && barB) {
        barA.style.width = `${percentageA}%`;
        barB.style.width = `${percentageB}%`;
        barA.textContent = `${percentageA}%`;
        barB.textContent = `${percentageB}%`;
    }

    const countA = document.getElementById('countA');
    const countB = document.getElementById('countB');
    
    if (countA && countB) {
        countA.textContent = `${votesA}표`;
        countB.textContent = `${votesB}표`;
    }
}

// 퍼센트 계산 함수
function calculatePercentage(votes, otherVotes) {
    const total = votes + otherVotes;
    return total === 0 ? 0 : Math.round((votes / total) * 100);
}

// 이전 투표 보기 함수
async function showPreviousVotes() {
    try {
        const now = new Date();
        // 모든 투표를 가져와서 클라이언트에서 필터링
        const snapshot = await db.collection('votes')
            .orderBy('exposureTime', 'desc')
            .get();

        const previousVotesBody = document.getElementById('previousVotesBody');
        previousVotesBody.innerHTML = '';

        snapshot.forEach(doc => {
            const vote = doc.data();
            const exposureTime = vote.exposureTime.toDate();
            const endTime = new Date(exposureTime.getTime() + 60 * 60 * 1000); // 1시간 후

            // 종료된 투표만 표시
            if (vote.status === 'ended' || now > endTime) {
                const row = document.createElement('tr');
                
                // 투표 결과 비교하여 스타일 적용
                const leftVotes = vote.votesA || 0;
                const rightVotes = vote.votesB || 0;
                const leftPercentage = calculatePercentage(leftVotes, rightVotes);
                const rightPercentage = calculatePercentage(rightVotes, leftVotes);
                
                const leftStyle = leftVotes > rightVotes ? 'color: #2196F3; font-weight: bold;' : '';
                const rightStyle = rightVotes > leftVotes ? 'color: #2196F3; font-weight: bold;' : '';
                
                row.innerHTML = `
                    <td>${exposureTime.toLocaleString('ko-KR', {
                        year: 'numeric',
                        month: '2-digit',
                        day: '2-digit',
                        hour: '2-digit',
                        minute: '2-digit'
                    })}</td>
                    <td>${vote.optionA}</td>
                    <td>${vote.optionB}</td>
                    <td style="${leftStyle}">${leftVotes} (${leftPercentage}%)</td>
                    <td style="${rightStyle}">${rightVotes} (${rightPercentage}%)</td>
                `;
                
                previousVotesBody.appendChild(row);

                // 상태가 ended가 아닌데 시간이 지난 경우 자동으로 상태 업데이트
                if (vote.status !== 'ended' && now > endTime) {
                    db.collection('votes').doc(doc.id).update({ status: 'ended' });
                }
            }
        });

        document.getElementById('previousVotesModal').classList.remove('hidden');
    } catch (error) {
        console.error('Error loading previous votes:', error);
        alert('이전 투표 목록을 불러오는 중 오류가 발생했습니다');
    }
}

// 이전 투표 모달 닫기
function closePreviousVotes() {
    document.getElementById('previousVotesModal').classList.add('hidden');
}

// 페이지 로드 시 초기화
document.addEventListener('DOMContentLoaded', () => {
    console.log('페이지 로드됨');
    // URL 파라미터로 관리자/사용자 페이지 구분
    const urlParams = new URLSearchParams(window.location.search);
    isAdmin = urlParams.get('admin') === 'true';  // 전역 변수에 관리자 상태 저장
    if (isAdmin) {
        showAdminPage();
    } else {
        showUserPage();
    }
});
